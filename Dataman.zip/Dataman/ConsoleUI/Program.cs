﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dataman_Library;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            int choice;
            string problem;
            Console.WriteLine(StandardMessages.DisplayMainMenu());
            
            
            while (!exit)
            {
                choice = StandardMessages.RequestInput();

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Please enter a problem and the answer. (ex. 4+4=8)\n");
                        Console.Write("Answer Checker >> ");
                        problem = Console.ReadLine();
                        Console.WriteLine(AnswerChecker.CheckAnswer(problem));
                        break;
                    case 2:
                        Console.WriteLine("Feature not added.");
                        break;
                    case 3:
                        Console.WriteLine("Feature not added.");
                        break;
                    case 4:
                        Console.WriteLine("Feature not added.");
                        break;
                    case 5:
                        exit = true;
                        break;
                }

            }
        }

        
    }
}
