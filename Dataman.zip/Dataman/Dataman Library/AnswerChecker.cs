﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dataman_Library
{
    public static class AnswerChecker
    {
        public static string CheckAnswer(string problem)
        {
            int userAnswer;
            string[] numbers = new string[problem.Length - 2];

            numbers = problem.Split('=');
            userAnswer = int.Parse(numbers[numbers.Length - 1]);

            if (numbers[0].Contains("+"))
            {
                numbers = numbers[0].Split('+');
                int answer = int.Parse(numbers[0]) + int.Parse(numbers[1]);

                if (userAnswer == answer)
                {
                    return "Answer Correct!";
                    // Add count
                }
                else
                {
                    return "Incorrect, Try again";
                }
            }
            else if (numbers[0].Contains("-"))
            {
                numbers = numbers[0].Split('-');
                int answer = int.Parse(numbers[0]) - int.Parse(numbers[1]);

                if (userAnswer == answer)
                {
                    return "Answer Correct!";
                    // Add count
                }
                else
                {
                    return "Incorrect, Try again";
                }
            }
            else if (numbers[0].Contains("*"))
            {
                numbers = numbers[0].Split('*');
                int answer = int.Parse(numbers[0]) * int.Parse(numbers[1]);

                if (userAnswer == answer)
                {
                    return "Answer Correct!";
                    // Add count
                }
                else
                {
                    return "Incorrect, Try again";
                }
            }
            else if (numbers[0].Contains("/"))
            {
                numbers = numbers[0].Split('/');
                int answer = int.Parse(numbers[0]) / int.Parse(numbers[1]);

                if (userAnswer == answer)
                {
                    return "Answer Correct!";
                    // Add count
                }
                else
                {
                    return "Incorrect, Try again";
                }
            }
            else
            {
                return "Invalid Input";
            }
        }
    }
}
