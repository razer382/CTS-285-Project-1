﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dataman_Library
{
    public static class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "\t\tMENU\n---------------------------------\n" +
                "1. Answer Checker\n" +
                "2. Memory Bank\n" +
                "3. Number Guesser\n" +
                "4. Additional Feature (Update)\n" +
                "5. Exit Program\n";
        }

        public static int RequestInput()
        {
            Console.Write("Choice >> ");
            return int.Parse(Console.ReadLine());
        }
    }
}
